// usage: node render.js preview t1,t2,... outdir   |  node render.js video start end fps out.mp4
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const path = require('path');
(async () => {
  const [mode, a, b, c, d] = process.argv.slice(2);
  const browser = await chromium.launch({ args: ['--allow-file-access-from-files', '--disable-web-security', '--font-render-hinting=none'] });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  page.on('console', (m) => { if (m.type() === 'error') console.error('PAGE:', m.text()); });
  page.on('pageerror', (e) => console.error('PAGEERR:', e.message));
  await page.goto('file://' + path.resolve(__dirname, 'video/index.html'));
  await page.evaluate(() => window.ready);
  const stage = await page.$('#stage');
  if (mode === 'preview') {
    const times = a.split(',').map(Number);
    for (const t of times) {
      await page.evaluate((t) => window.seek(t), t);
      await stage.screenshot({ path: `${b}/f_${t.toFixed(2)}.png` });
    }
  } else {
    const start = +a, end = +b, fps = +c;
    const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '14', '-pix_fmt', 'yuv420p', d], { stdio: ['pipe', 'inherit', 'inherit'] });
    const n0 = Math.round(start * fps), n1 = Math.round(end * fps);
    const t0 = Date.now();
    for (let n = n0; n < n1; n++) {
      await page.evaluate((t) => window.seek(t), n / fps);
      const buf = await stage.screenshot({ type: 'png' });
      if (!ff.stdin.write(buf)) await new Promise((r) => ff.stdin.once('drain', r));
      if ((n - n0) % 120 === 0) console.log(`frame ${n}/${n1} ${((Date.now() - t0) / 1000).toFixed(0)}s`);
    }
    ff.stdin.end();
    await new Promise((r) => ff.on('close', r));
  }
  await browser.close();
})();
