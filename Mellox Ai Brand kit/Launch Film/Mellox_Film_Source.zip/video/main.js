/* Mellox AI launch film. Deterministic: window.seek(t) renders time t. */
gsap.registerPlugin(CustomEase, DrawSVGPlugin);
CustomEase.create('emph', 'M0,0 C0.22,1 0.36,1 1,1');
const EMPH = gsap.parseEase('emph');
const S = document.getElementById('stage');
const tl = gsap.timeline({ paused: true });
const D = [];
const DURATION = 47.2;

/* ---------- helpers ---------- */
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const seg = (t, a, b) => clamp((t - a) / (b - a));
const smooth = (x) => x * x * (3 - 2 * x);
const eio = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const lerp = (a, b, x) => a + (b - a) * x;
function el(html) { const d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstElementChild; }
function add(parent, html) { const e = el(html); parent.appendChild(e); return e; }
function layer(id, cls = '', z = 1) { return add(S, `<div id="${id}" class="layer ${cls}" style="z-index:${z}"></div>`); }
function show(l, a, b) { tl.set(l, { visibility: 'visible' }, a); if (b != null) tl.set(l, { visibility: 'hidden' }, b); }
const words = (text) => text.split(' ').map((w) => `<span class="w">${w}</span>`).join(' ');
function wIn(targets, at, o = {}) {
  tl.fromTo(targets, { opacity: 0, y: o.y ?? 34, filter: `blur(${o.blur ?? 14}px)` },
    { opacity: 1, y: 0, filter: 'blur(0px)', duration: o.dur ?? 0.9, ease: 'emph', stagger: o.stagger ?? 0.075 }, at);
}
function wOut(targets, at, o = {}) {
  tl.to(targets, { opacity: 0, y: o.y ?? -26, filter: `blur(${o.blur ?? 12}px)`, duration: o.dur ?? 0.45, ease: 'power2.in', stagger: o.stagger ?? 0.025 }, at);
}
function popIn(targets, at, o = {}) {
  tl.fromTo(targets, { opacity: 0, scale: o.from ?? 0.5, y: o.y ?? 0 },
    { opacity: 1, scale: 1, y: 0, duration: o.dur ?? 0.6, ease: o.ease ?? 'back.out(1.8)', stagger: o.stagger ?? 0 }, at);
}
function riseIn(targets, at, o = {}) {
  tl.fromTo(targets, { opacity: 0, y: o.y ?? 40, scale: o.scale ?? 0.97, filter: `blur(${o.blur ?? 10}px)` },
    { opacity: 1, y: 0, scale: 1, filter: 'blur(0px)', duration: o.dur ?? 0.8, ease: 'emph', stagger: o.stagger ?? 0 }, at);
}
function typer(node, text, start, cps, caret = true, placeholder = '') {
  D.push((t) => {
    const n = Math.floor(clamp((t - start) * cps, 0, text.length));
    const blink = caret && (n < text.length || Math.floor(t * 2.2) % 2 === 0) && t > start - 0.4 && t < start + text.length / cps + 0.9;
    if (n === 0 && placeholder && t < start) { node.innerHTML = `<span style="color:#a3a99b">${placeholder}</span>`; return; }
    node.innerHTML = text.slice(0, n) + (blink ? '<span style="display:inline-block;width:2px;height:1em;background:currentColor;vertical-align:-0.14em;margin-left:2px"></span>' : '');
  });
}
function counter(node, pts, fmt = (v) => Math.round(v)) {
  // pts: [[t, value], ...] eased between
  D.push((t) => {
    let v = pts[0][1];
    for (let i = 1; i < pts.length; i++) {
      const [ta, va] = pts[i - 1], [tb, vb] = pts[i];
      if (t >= ta) v = lerp(va, vb, EMPH(seg(t, ta, tb)));
    }
    node.textContent = fmt(v);
  });
}

/* ---------- glyphs ---------- */
const MARK = 'M345.833 233.931C348.699 231.573 352.737 231.268 355.925 233.168C359.573 235.343 361.146 239.815 359.662 243.795L350.61 268.077L311.897 373.654L369.883 319.129C370.769 318.296 371.928 317.814 373.143 317.774L482.638 314.17C486.829 314.032 490.697 316.408 492.468 320.209C494.533 324.641 493.254 329.913 489.387 332.906L400.294 401.844C393.461 407.131 385.066 410 376.427 410H350.61L418.574 360.673L296.539 408.273C293.76 409.356 290.629 409.028 288.136 407.393C284.645 405.103 283.131 400.753 284.444 396.79L311.897 313.942L252.718 407.669C251.802 409.12 250.206 410 248.49 410H154.619C151.172 410 148.096 407.834 146.934 404.588C145.774 401.345 146.774 397.723 149.433 395.535L345.833 233.931Z';
const markSvg = (w, fill = '#CBE960', extra = '') => `<svg width="${w}" height="${w * 195 / 360}" viewBox="140 225 360 195" ${extra}><path d="${MARK}" fill="${fill}"/></svg>`;
const SYM = {
  brand: { c: '#B489D1', d: 'M47 47H228.667V228.667H47V47ZM410.333 47H592V228.667H410.333V47ZM228.667 228.667H410.333V410.333H228.667V228.667ZM47 410.333H228.667V592H47V410.333ZM410.333 410.333H592V592H410.333V410.333Z' },
  customer: { c: '#FE7032', d: 'M373.2 266.8H266.8V373.2H373.2V266.8ZM54 373.2H160.4V266.8H54V160.4H266.8V54H373.2V160.4H479.6V54H586V266.8H479.6V373.2H586V479.6H373.2V586H266.8V479.6H160.4V586H54V373.2Z' },
  competitor: { c: '#2F7BFF', d: 'M82 43H557V201.286H477.833V122.143H161.167V517.857H398.667V597H82V43ZM240.333 201.286H477.833V359.571H557V438.714H240.333V201.286ZM319.5 359.571H398.667V280.429H319.5V359.571Z' },
  market: { c: '#EE3445', d: 'M493.2 39H606V151.8H493.2V39ZM42 39H154.8V151.8H42V39ZM380.4 151.8H493.2V264.6H380.4V151.8ZM267.6 264.6H380.4V377.4H267.6V264.6ZM154.8 377.4H267.6V490.2H154.8V377.4ZM42 490.2H154.8V603H42V490.2ZM493.2 490.2H606V603H493.2V490.2Z' },
};
const symSvg = (k, s, fill) => `<svg width="${s}" height="${s}" viewBox="0 0 640 640"><path d="${SYM[k].d}" fill="${fill || SYM[k].c}"/></svg>`;
const BC = { openai: '#0d0d0d', gemini: '#4285F4', claude: '#D97757', meta: '#0866FF', facebook: '#1877F2', tiktok: '#0d0d0d', linkedin: '#0A66C2', x: '#0d0d0d', threads: '#0d0d0d', instagram: '#E1306C', youtube: '#FF0000', perplexity: '#1FB8CD' };
function logo(name, size, color) {
  const P = BRAND_PATHS[name];
  if (name === 'google') {
    const gc = ['#4285F4', '#34A853', '#FBBC05', '#EA4335'];
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24">${P.map((d, i) => `<path fill="${color || gc[i]}" d="${d}"/>`).join('')}</svg>`;
  }
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="${color || BC[name]}">${P.map((d) => `<path d="${d}"/>`).join('')}</svg>`;
}
const ic = {
  spark: (s = 22, c = 'currentColor') => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="${c}"><path d="M12 2.5c.5 4.9 2.6 7 7.5 7.5-4.9.5-7 2.6-7.5 7.5-.5-4.9-2.6-7-7.5-7.5 4.9-.5 7-2.6 7.5-7.5Z"/><path opacity=".55" d="M19 15.5c.2 2 1 2.8 3 3-2 .2-2.8 1-3 3-.2-2-1-2.8-3-3 2-.2 2.8-1 3-3Z"/></svg>`,
  up: (s = 22) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>`,
  check: (s = 16) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>`,
  globe: (s = 24) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.8 3.9 5.8 3.9 9s-1.3 6.2-3.9 9c-2.6-2.8-3.9-5.8-3.9-9S9.4 5.8 12 3Z"/></svg>`,
  cal: (s = 20) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>`,
  play: (s = 22) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13l11-6.5z"/></svg>`,
  trend: (s = 14) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17l6-6 4 4 8-8M15 7h6v6"/></svg>`,
  cursor: `<svg width="34" height="34" viewBox="0 0 24 24"><path d="M5 3l14 7.2-6.1 1.6-2.9 6.2z" fill="#111" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/></svg>`,
};

/* ---------- grain ---------- */
(function grain() {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d'); const id = g.createImageData(256, 256);
  let s = 1234567; const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < id.data.length; i += 4) { const v = rnd() * 255; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; }
  g.putImageData(id, 0, 0);
  const gr = add(S, `<div id="grain" style="background-image:url(${c.toDataURL()})"></div>`);
  D.push((t) => { const f = Math.floor(t * 30); gr.style.transform = `translate(${(f * 37) % 64 - 32}px,${(f * 53) % 64 - 32}px)`; });
})();

/* =========================================================
   L0 - light world background (0 - 10.8)
   ========================================================= */
const L0 = layer('L0', 'lightbg', 1); show(L0, 0, 10.8);
const orbA = add(L0, `<div class="orb" style="width:1400px;height:1400px;background:radial-gradient(circle,rgba(203,233,96,.60) 0%,rgba(203,233,96,.18) 35%,rgba(203,233,96,0) 64%)"></div>`);
const orbB = add(L0, `<div class="orb" style="width:1300px;height:1300px;background:radial-gradient(circle,rgba(7,86,231,.16) 0%,rgba(7,86,231,0) 62%)"></div>`);
const orbC = add(L0, `<div class="orb" style="width:1100px;height:1100px;background:radial-gradient(circle,rgba(180,137,209,.26) 0%,rgba(180,137,209,0) 62%)"></div>`);
add(L0, `<div class="dots"></div>`);
D.push((t) => {
  orbA.style.transform = `translate(${-240 + Math.sin(t * 0.33) * 160}px,${-560 + Math.cos(t * 0.27) * 110}px)`;
  orbB.style.transform = `translate(${880 + Math.cos(t * 0.29) * 150}px,${160 + Math.sin(t * 0.31) * 100}px)`;
  orbC.style.transform = `translate(${1150 + Math.sin(t * 0.25 + 1) * 140}px,${-520 + Math.cos(t * 0.35) * 90}px)`;
});

/* =========================================================
   S1 - Your customers stopped searching (0 - 3.2)
   ========================================================= */
const S1 = layer('S1', '', 5); show(S1, 0, 3.3);
const h1 = add(S1, `<div class="abs center-x head" style="top:466px;font-size:112px">${words("Your customers stopped searching.")}</div>`);
wIn(h1.querySelectorAll('.w'), 0.2, { stagger: 0.11, dur: 1.1, y: 44, blur: 18 });
tl.fromTo(h1, { scale: 1.0 }, { scale: 1.035, duration: 3, ease: 'none' }, 0);
wOut(h1.querySelectorAll('.w'), 2.35, { stagger: 0.03 });

/* =========================================================
   S2 - They ask AI (3.0 - 7.5)
   ========================================================= */
const S2 = layer('S2', '', 6); show(S2, 2.95, 7.55);
const discs = [
  ['openai', 250, 250], ['gemini', 170, 610], ['meta', 330, 960],
  ['claude', 1680, 250], ['perplexity', 1760, 600], ['google', 1590, 960],
].map(([k, x, y], i) => {
  const d = add(S2, `<div class="logoDisc" style="left:${x - 54}px;top:${y - 54}px">${logo(k, 50)}</div>`);
  D.push((t) => { d.style.translate = `${Math.sin(t * 0.8 + i * 1.7) * 10}px ${Math.cos(t * 0.7 + i) * 12}px`; });
  return d;
});
popIn(discs, 3.15, { stagger: 0.08, from: 0.4, dur: 0.8 });
tl.to(discs, { opacity: 0, scale: 0.7, filter: 'blur(8px)', duration: 0.45, ease: 'power2.in', stagger: 0.03 }, 6.95);

const pbar = add(S2, `<div class="card abs" style="left:440px;top:490px;width:1040px;height:100px;border-radius:50px">
  <div class="abs" style="left:22px;top:22px;width:56px;height:56px;border-radius:50%;display:grid;place-items:center;background:rgba(210,232,97,.45);color:#2f6b08">${ic.spark(26)}</div>
  <div id="ptext" class="abs" style="left:98px;top:0;line-height:100px;font-size:33px;color:#15190f;letter-spacing:-.01em"></div>
  <div id="psend" class="abs" style="right:18px;top:18px;width:64px;height:64px;border-radius:50%;display:grid;place-items:center;color:#fff;background:#c9cdc2">${ic.up(26)}</div>
</div>`);
riseIn(pbar, 3.0, { y: 50, scale: 0.92, dur: 1.0 });
const Q = "What's the best serum for sensitive skin?";
typer(pbar.querySelector('#ptext'), Q, 3.5, 31, true, 'Ask anything');
const psend = pbar.querySelector('#psend');
D.push((t) => { psend.style.background = t > 3.5 + Q.length / 31 ? '#15190f' : '#c9cdc2'; });
tl.to(psend, { scale: 0.84, duration: 0.12, yoyo: true, repeat: 1, ease: 'power2.out' }, 4.95);
tl.to(pbar, { y: -300, duration: 0.8, ease: 'emph' }, 5.05);

const ans = add(S2, `<div class="card abs" style="left:440px;top:318px;width:1040px;height:468px;border-radius:28px;padding:30px 34px">
  <div style="display:flex;align-items:center;gap:12px">${logo('openai', 30)}<span style="font-size:22px;font-weight:650">ChatGPT</span>
    <span style="margin-left:auto;display:flex;gap:8px;align-items:center;color:#8a9182;font-size:16px">${logo('gemini', 20)}${logo('claude', 20)}${logo('perplexity', 20)}<span style="margin-left:4px">same question, every engine</span></span></div>
  <div id="think" class="abs shimmer" style="left:34px;top:88px;font-size:21px;font-weight:600">Thinking</div>
  <div id="intro" class="abs" style="left:34px;top:88px;font-size:21px;color:#3b4136"></div>
  <div id="rows"></div>
</div>`);
riseIn(ans, 5.3, { y: 60, dur: 0.9 });
const think = ans.querySelector('#think');
tl.fromTo(think, { opacity: 0 }, { opacity: 1, duration: 0.2 }, 5.45);
tl.to(think, { opacity: 0, duration: 0.15 }, 5.95);
D.push((t) => { think.style.backgroundPosition = `${(1 - ((t * 0.9) % 1)) * 150}% 0`; });
typer(ans.querySelector('#intro'), 'Top picks for sensitive skin, based on reviews and dermatologist advice:', 6.0, 110, false);
const rowsEl = ans.querySelector('#rows');
const rowW = [[210, 330], [170, 380], [240, 290]];
const rows = rowW.map(([a, b], i) => add(rowsEl, `<div class="abs" style="left:34px;top:${140 + i * 66}px;width:972px;height:54px;display:flex;align-items:center;gap:18px;padding:0 14px;border-radius:14px;background:#f7f8f4">
  <span style="width:32px;height:32px;border-radius:50%;background:#fff;display:grid;place-items:center;font-size:15px;font-weight:700;color:#6b7263;box-shadow:0 0 0 1px rgba(0,0,0,.06)">${i + 1}</span>
  <span class="sk" style="width:${a}px;background:#d9ddd2"></span><span class="sk" style="width:${b}px"></span>
  <span style="margin-left:auto" class="chip"><span style="color:#2f6b08">${ic.check(15)}</span><span style="color:#4b5245;font-size:15px">Recommended</span></span></div>`));
const miss = add(rowsEl, `<div class="abs" style="left:34px;top:${140 + 3 * 66 + 8}px;width:972px;height:62px;display:flex;align-items:center;gap:18px;padding:0 14px;border-radius:14px;border:2px dashed rgba(200,16,46,.35);background:#fff8f8">
  <span style="width:32px;height:32px;border-radius:50%;background:#fff;display:grid;place-items:center;font-size:16px;font-weight:700;color:#b8bdb2;box-shadow:0 0 0 1px rgba(0,0,0,.06)">?</span>
  <span style="font-size:22px;font-weight:650;color:#15190f">Lumora</span><span style="font-size:17px;color:#8a9182">your brand</span>
  <span id="nm" class="chip" style="margin-left:auto;background:#FDECEC;color:#B4121F;font-size:16px">Not mentioned</span></div>`);
riseIn(rows, 6.25, { stagger: 0.12, y: 18, dur: 0.6, blur: 6 });
riseIn(miss, 6.7, { y: 18, dur: 0.6, blur: 6 });
popIn(miss.querySelector('#nm'), 6.95, { from: 1.35, ease: 'back.out(3)', dur: 0.5 });

const cap2 = add(S2, `<div class="abs center-x head" style="top:846px;font-size:60px">${words("They ask AI. And AI doesn't mention you.")}</div>`);
wIn(cap2.querySelectorAll('.w'), 5.75, { stagger: 0.07, dur: 0.9 });
tl.to([pbar, ans, cap2], { opacity: 0, scale: 0.96, filter: 'blur(12px)', duration: 0.5, ease: 'power2.in' }, 7.05);

/* =========================================================
   S3 - juggling 12 tools (7.2 - 10.8)
   ========================================================= */
const S3 = layer('S3', '', 7); show(S3, 7.2, 10.8);
const TOOLS = [
  ['SEO audit.xlsx', 120, 90, -6, '#E4F1DC', 'grid', 3], ['Content calendar', 520, 60, 4, '#E3EEFB', 'cal', 0], ['Brand guidelines.pdf', 930, 110, -3, '#FBE7E7', 'doc', 0],
  ['Scheduler', 1330, 70, 5, '#F2E8FA', 'clock', 5], ['Analytics', 1620, 250, -4, '#FFF1DE', 'bars', 0], ['Competitor notes', -70, 500, 3, '#EEF0EA', 'lines', 0],
  ['Keyword tool', 1700, 520, 6, '#E3F4F6', 'search', 2], ['AI chat', 140, 780, -5, '#E9F3D8', 'chat', 0], ['Approvals thread', 540, 840, 4, '#FDE9DF', 'check', 9],
  ['Design tool', 960, 820, -2, '#E8E6FB', 'pen', 0], ['Social inbox', 1360, 850, 5, '#FCE6EF', 'inbox', 14], ['Client report.pptx', 350, 300, -7, '#FFF4D6', 'slides', 0],
];
const glyph = (k) => {
  const p = { grid: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 10h16M4 15h16M10 4v16"/>', cal: '<rect x="4" y="5" width="16" height="15" rx="3"/><path d="M4 10h16M8 3v4M16 3v4"/>', doc: '<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4M9.5 12h6M9.5 16h6"/>', clock: '<circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/>', bars: '<path d="M5 20V11M10 20V5M15 20v-7M20 20V8"/>', lines: '<path d="M5 6h14M5 11h14M5 16h9"/>', search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>', chat: '<path d="M4 5h16v11H9l-5 4z"/>', check: '<path d="M4 12.5l5 5L20 6.5"/>', pen: '<path d="M4 20l4-1L19 8l-3-3L5 16z"/>', inbox: '<path d="M4 13l3-8h10l3 8v6H4z"/><path d="M4 13h5l1 2h4l1-2h5"/>', slides: '<rect x="3.5" y="5" width="17" height="11" rx="2"/><path d="M12 16v4M8 20h8"/>' }[k];
  return `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#3a4034" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
};
const mws = TOOLS.map(([name, x, y, r, bg, g, badge], i) => {
  const w = add(S3, `<div class="mw" style="left:${x}px;top:${y}px;rotate:${r}deg">
    <div class="bar"><span class="d" style="background:#ff5f57"></span><span class="d" style="background:#febc2e"></span><span class="d" style="background:#28c840"></span><span style="margin-left:6px">${name}</span></div>
    <div class="body"><div class="ic" style="background:${bg}">${glyph(g)}</div>
      <div style="flex:1;display:flex;flex-direction:column;gap:10px;padding-top:4px"><div class="sk" style="width:${70 + (i * 37) % 60}%"></div><div class="sk" style="width:${50 + (i * 53) % 40}%;background:#eff1ea"></div><div class="sk" style="width:${35 + (i * 29) % 45}%;background:#f2f4ee"></div></div></div>
    ${badge ? `<div class="badge">${badge}</div>` : ''}</div>`);
  D.push((t) => { w.style.translate = `${Math.sin(t * 1.1 + i * 2.1) * 7}px ${Math.cos(t * 0.9 + i * 1.3) * 8}px`; });
  return { w, x, y, r };
});
const order = [5, 0, 11, 7, 2, 9, 1, 8, 3, 10, 4, 6];
tl.fromTo(order.map((i) => mws[i].w), { opacity: 0, scale: 0.6, y: 60 }, { opacity: 1, scale: 1, y: 0, duration: 0.7, ease: 'back.out(1.5)', stagger: 0.06 }, 7.25);
const badges = S3.querySelectorAll('.badge');
popIn(badges, 8.5, { stagger: 0.09, from: 0, ease: 'back.out(3)', dur: 0.45 });
const cap3 = add(S3, `<div class="abs center-x head" style="top:494px;font-size:74px">${words("And you're juggling 12 tools to fix it.")}</div>`);
wIn(cap3.querySelectorAll('.w'), 7.7, { stagger: 0.07 });
wOut(cap3.querySelectorAll('.w'), 9.2, { stagger: 0.02, dur: 0.35 });
mws.forEach(({ w, x, y }, k) => {
  tl.to(w, { x: 960 - (x + 145), y: 540 - (y + 92), rotate: (k % 2 ? 1 : -1) * 40, scale: 0.05, opacity: 0, duration: 0.62, ease: 'power3.in' }, 9.32 + (k % 6) * 0.025);
});
const dot = add(S3, `<div class="abs" style="left:942px;top:522px;width:36px;height:36px;border-radius:50%;background:#CBE960;box-shadow:0 0 40px 8px rgba(203,233,96,.7)"></div>`);
tl.fromTo(dot, { scale: 0, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.3, ease: 'back.out(2.5)' }, 9.85);

/* =========================================================
   S4 + S5 - Reveal and four brains (10.0 - 17.9)
   ========================================================= */
const S4 = layer('S4', '', 8); show(S4, 9.98, 17.95);
tl.fromTo(S4, { clipPath: 'circle(0px at 960px 540px)' }, { clipPath: 'circle(1250px at 960px 540px)', duration: 0.8, ease: 'expo.inOut' }, 10.0);
const s4bg = add(S4, `<div class="abs" style="inset:0;background:radial-gradient(1200px 820px at 88% -8%,rgba(203,233,96,.46),rgba(203,233,96,0) 62%),radial-gradient(900px 700px at -5% 108%,rgba(203,233,96,.16),rgba(203,233,96,0) 60%),#39444A"></div>`);
const t1 = add(S4, `<img class="abs" src="assets/t1.jpg" style="left:-110px;top:-25px;width:2140px;height:1130px;-webkit-mask-image:radial-gradient(ellipse 58% 55% at 50% 48%,transparent 35%,#000 88%)">`);
tl.fromTo(t1, { opacity: 0, scale: 1.18 }, { opacity: 0.55, scale: 1.0, duration: 3.6, ease: 'power2.out' }, 10.2);
const darken = add(S4, `<div class="abs" style="inset:0;background:radial-gradient(900px 700px at 50% 52%,#10181a 0%,#060808 70%);opacity:0"></div>`);
tl.to(darken, { opacity: 1, duration: 0.9, ease: 'power2.inOut' }, 13.25);
tl.to(t1, { opacity: 0, duration: 0.9 }, 13.25);

const markWrap = add(S4, `<div class="abs" style="left:730px;top:282px;width:460px;height:250px;z-index:5">
  <svg width="460" height="250" viewBox="140 225 360 195" style="overflow:visible">
    <defs><linearGradient id="sw" x1="0" x2="1" y1="0" y2=".3"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".85"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
    <clipPath id="mclip"><path d="${MARK}"/></clipPath></defs>
    <path id="mpath" d="${MARK}" fill="#CBE960" fill-opacity="0" stroke="#CBE960" stroke-width="2.4"/>
    <g clip-path="url(#mclip)"><rect id="msweep" x="0" y="200" width="140" height="260" fill="url(#sw)" opacity="0"/></g>
  </svg></div>`);
const mpath = markWrap.querySelector('#mpath');
tl.fromTo(mpath, { drawSVG: '0% 0%' }, { drawSVG: '0% 100%', duration: 0.9, ease: 'power2.inOut' }, 10.35);
tl.to(mpath, { attr: { 'fill-opacity': 1, 'stroke-opacity': 0 }, duration: 0.45, ease: 'power2.out' }, 11.0);
tl.fromTo(markWrap, { scale: 0.76, rotate: -7, opacity: 0.2 }, { scale: 1, rotate: 0, opacity: 1, duration: 1.4, ease: 'emph' }, 10.25);
const msweep = markWrap.querySelector('#msweep');
tl.fromTo(msweep, { attr: { x: 60, opacity: 1 } }, { attr: { x: 520 }, duration: 0.9, ease: 'power2.inOut' }, 11.45);
tl.set(msweep, { attr: { opacity: 0 } }, 12.4);

const wm = add(S4, `<div class="abs center-x" style="top:572px;font-family:Mich;font-size:100px;color:#fff;letter-spacing:0.04em;z-index:5">${'Mellox Ai'.split('').map((c) => `<span class="w">${c === ' ' ? '&nbsp;' : c}</span>`).join('')}</div>`);
tl.fromTo(wm, { letterSpacing: '0.55em' }, { letterSpacing: '0.04em', duration: 1.2, ease: 'emph' }, 11.1);
tl.fromTo(wm.querySelectorAll('.w'), { opacity: 0, filter: 'blur(14px)' }, { opacity: 1, filter: 'blur(0px)', duration: 0.8, stagger: 0.05, ease: 'power2.out' }, 11.1);
const sub4 = add(S4, `<div class="abs center-x" style="top:722px;font-size:44px;color:rgba(255,255,255,.76);letter-spacing:-.01em;z-index:5">${words('Your marketing brain.')}</div>`);
wIn(sub4.querySelectorAll('.w'), 12.05, { stagger: 0.09 });
wOut([...wm.querySelectorAll('.w'), ...sub4.querySelectorAll('.w')], 13.15, { stagger: 0.015, dur: 0.4 });
tl.to(markWrap, { y: 153, scale: 0.3, duration: 0.95, ease: 'emph' }, 13.2);

/* S5 - four brains */
const core = add(S4, `<div class="abs" style="left:760px;top:360px;width:400px;height:400px;z-index:3;opacity:0">
  <div class="abs" style="inset:-120px;background:radial-gradient(circle,rgba(203,233,96,.28) 0%,rgba(203,233,96,0) 55%)"></div>
  <svg class="abs" style="inset:0" width="400" height="400"><circle id="ring1" cx="200" cy="200" r="118" fill="none" stroke="rgba(203,233,96,.55)" stroke-width="2" stroke-dasharray="3 11"/>
  <circle cx="200" cy="200" r="150" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="1.5"/><circle cx="200" cy="200" r="86" fill="rgba(203,233,96,.06)" stroke="rgba(203,233,96,.25)" stroke-width="1.5"/></svg></div>`);
tl.fromTo(core, { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1, duration: 1.0, ease: 'emph' }, 13.7);
const ring1 = core.querySelector('#ring1');
D.push((t) => { ring1.style.transform = `rotate(${t * 22}deg)`; ring1.style.transformOrigin = '200px 200px'; const g = 1 + Math.sin(t * 3.2) * 0.04; core.firstElementChild.style.transform = `scale(${g})`; });

const h5 = add(S4, `<div class="abs center-x head" style="top:92px;font-size:62px;color:#fff;z-index:6">${words('It thinks like your best marketer.')}</div>`);
wIn(h5.querySelectorAll('.w'), 13.85, { stagger: 0.07 });
const h5b = add(S4, `<div class="abs center-x" style="top:176px;font-size:27px;color:rgba(255,255,255,.58);z-index:6">${words('Four brains. One reasoning core.')}</div>`);
wIn(h5b.querySelectorAll('.w'), 14.45, { stagger: 0.06, y: 18, blur: 8 });

const CORE = [960, 560];
const BR = [
  ['brand', 'Brand Brain', 'Your voice, story and positioning', 470, 395, 'L'],
  ['customer', 'Customer Brain', 'Who buys, and what they ask', 1450, 395, 'R'],
  ['competitor', 'Competitor Brain', 'Every move your rivals make', 470, 815, 'L'],
  ['market', 'Market Brain', "What's rising in your market", 1450, 815, 'R'],
];
const lineSvg = add(S4, `<svg class="abs" style="left:0;top:0;z-index:2" width="1920" height="1080"></svg>`);
const nodes = BR.map(([k, name, desc, x, y, side], i) => {
  const L = side === 'L';
  const n = add(S4, `<div class="abs" style="left:${x - 250}px;top:${y - 66}px;width:500px;height:132px;display:flex;align-items:center;gap:26px;flex-direction:${L ? 'row-reverse' : 'row'};z-index:4">
    <div style="width:132px;height:132px;flex:none;border-radius:30px;background:#121617;display:grid;place-items:center;box-shadow:0 0 0 1px rgba(255,255,255,.08) inset,0 0 60px -10px ${SYM[k].c}66">${symSvg(k, 70)}</div>
    <div style="text-align:${L ? 'right' : 'left'}"><div style="font-size:33px;font-weight:600;color:#fff;letter-spacing:-.01em">${name}</div><div style="font-size:21px;color:rgba(255,255,255,.6);margin-top:6px">${desc}</div></div></div>`);
  const sx = L ? x + 250 : x - 250 + 0; // inner edge of symbol box
  const sy = y;
  const ang = Math.atan2(sy - CORE[1], sx - CORE[0]);
  const ex = CORE[0] + Math.cos(ang) * 128, ey = CORE[1] + Math.sin(ang) * 128;
  const d = `M${sx},${sy} C${sx + (L ? 90 : -90)},${sy} ${ex + Math.cos(ang) * 90},${ey + Math.sin(ang) * 60} ${ex},${ey}`;
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', d); p.setAttribute('fill', 'none'); p.setAttribute('stroke', SYM[k].c); p.setAttribute('stroke-opacity', '.55'); p.setAttribute('stroke-width', '2');
  lineSvg.appendChild(p);
  const dots = [0, 1, 2].map(() => { const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle'); c.setAttribute('r', '5'); c.setAttribute('fill', SYM[k].c); c.style.filter = `drop-shadow(0 0 6px ${SYM[k].c})`; lineSvg.appendChild(c); return c; });
  const len = p.getTotalLength();
  D.push((t) => {
    const on = t > 15.0 && t < 17.9;
    dots.forEach((c, j) => {
      const ph = ((t - 15.0) * 0.75 + j / 3 + i * 0.13) % 1;
      const pt = p.getPointAtLength(len * EMPH(ph));
      c.setAttribute('cx', pt.x); c.setAttribute('cy', pt.y);
      c.setAttribute('opacity', on ? (Math.sin(ph * Math.PI) * 0.95).toFixed(3) : 0);
    });
  });
  tl.fromTo(p, { drawSVG: '0% 0%' }, { drawSVG: '0% 100%', duration: 0.9, ease: 'power2.inOut' }, 14.55 + i * 0.1);
  return n;
});
riseIn(nodes, 14.15, { stagger: 0.14, y: 24, scale: 0.9, blur: 12, dur: 0.9 });
tl.to([...nodes, lineSvg, core, h5, h5b, markWrap], { opacity: 0, duration: 0.45, ease: 'power2.in' }, 17.3);
tl.to(lineSvg, { scale: 1.5, transformOrigin: '960px 560px', duration: 0.6, ease: 'power2.in' }, 17.2);
tl.to([core, markWrap], { scale: '+=1.4', duration: 0.6, ease: 'power2.in' }, 17.2);

/* =========================================================
   S6 - Product tour on light stage (17.45 - 33.9)
   ========================================================= */
const S6 = layer('S6', 'pstage', 9); show(S6, 17.45, 33.95);
tl.fromTo(S6, { opacity: 0 }, { opacity: 1, duration: 0.35, ease: 'power1.out' }, 17.45);
add(S6, `<div class="abs" style="left:900px;top:40px;width:900px;height:900px;border-radius:50%;background:radial-gradient(closest-side,rgba(207,231,194,.85),rgba(207,231,194,0))"></div>`);
const orbD = add(S6, `<div class="orb" style="width:1100px;height:1100px;background:radial-gradient(circle,rgba(203,233,96,.34) 0%,rgba(203,233,96,0) 62%)"></div>`);
D.push((t) => { orbD.style.transform = `translate(${-380 + Math.sin(t * 0.3) * 120}px,${-420 + Math.cos(t * 0.25) * 90}px)`; });
add(S6, `<div class="dots" style="-webkit-mask-image:radial-gradient(ellipse 45% 55% at 68% 50%,#000 20%,transparent 80%)"></div>`);
const flash = add(S6, `<div class="abs" style="inset:0;background:#fff;z-index:30"></div>`);
tl.fromTo(flash, { opacity: 1 }, { opacity: 0, duration: 0.6, ease: 'power2.out' }, 17.75);

// progress (AuthShowcase style)
const FEAT = [['Brand DNA', 17.75, 21.75], ['Visibility', 21.75, 25.75], ['Create', 25.75, 29.75], ['Publish', 29.75, 33.75]];
const prog = add(S6, `<div class="abs" style="left:140px;top:840px;display:flex;gap:14px;z-index:3"></div>`);
FEAT.forEach(([n, a, b], i) => {
  const s = add(prog, `<div style="width:118px"><div style="height:4px;border-radius:4px;background:rgba(21,25,15,.10);overflow:hidden"><div style="height:100%;width:0;background:#15190f;border-radius:4px"></div></div><div style="margin-top:10px;font-size:15px;font-weight:600;color:#9aa092">${n}</div></div>`);
  const fill = s.firstElementChild.firstElementChild, lab = s.lastElementChild;
  D.push((t) => { fill.style.width = `${seg(t, a, b) * 100}%`; lab.style.color = t >= a && t < b ? '#15190f' : '#9aa092'; });
});
riseIn(prog, 18.0, { y: 14, blur: 4, dur: 0.6 });

// captions
const CAPS = [
  ['01', 'Brand DNA', 'Paste your website. Mellox learns your brand.', 'Voice, audience and positioning in under a minute.'],
  ['02', 'AI Visibility', 'See how AI sees you. Then fix it.', 'Audits across ChatGPT, Gemini, Claude and Perplexity.'],
  ['03', 'Studio', 'Posts that sound like you. Not like AI.', 'Copy, images and video, grounded in your Brand DNA.'],
  ['04', 'Publishing', 'Approve once. Live on 7 platforms.', 'Nothing goes out without your say.'],
];
CAPS.forEach(([num, lab, head, sub], i) => {
  const [, a, b] = FEAT[i];
  const g = add(S6, `<div class="abs" style="left:140px;top:300px;width:700px;z-index:3">
    <div style="display:flex;align-items:center;gap:16px"><span class="eyebrow w">${num}</span><span class="eylabel w">${lab}</span></div>
    <div class="head" style="margin-top:26px;font-size:74px">${words(head)}</div>
    <div style="margin-top:28px;font-size:26px;line-height:1.35;color:#6b7263;width:560px">${words(sub)}</div></div>`);
  const ws = g.querySelectorAll('.w');
  wIn(ws, a + 0.12, { stagger: 0.045, dur: 0.85 });
  if (i < 3) wOut(ws, b - 0.4, { stagger: 0.012, dur: 0.35 }); else wOut(ws, b - 0.35, { stagger: 0.01, dur: 0.35 });
});

// right side 3D product
const pw = add(S6, `<div class="abs" style="left:900px;top:0;width:960px;height:1080px;perspective:2200px;z-index:4"></div>`);
const pr = add(pw, `<div class="abs" style="inset:0;transform-style:preserve-3d"></div>`);
D.push((t) => { pr.style.transform = `scale(1.07) rotateY(${-9 + Math.sin(t * 0.32) * 3.5}deg) rotateX(${5 + Math.cos(t * 0.27) * 1.5}deg)`; });
const cur = add(pr, `<div class="abs" style="left:0;top:0;width:34px;height:34px;z-index:40;opacity:0">${ic.cursor}</div>`);
const rip = add(pr, `<div class="abs" style="left:0;top:0;width:64px;height:64px;margin:-32px 0 0 -32px;border-radius:50%;border:3px solid rgba(47,107,8,.75);z-index:39;opacity:0"></div>`);
function click(x, y, at, from) {
  tl.set(cur, { x: from[0], y: from[1] }, at - 0.75);
  tl.to(cur, { opacity: 1, duration: 0.2, immediateRender: false }, at - 0.75);
  tl.to(cur, { x, y, duration: 0.65, ease: 'power3.inOut' }, at - 0.7);
  tl.to(cur, { scale: 0.82, duration: 0.08, yoyo: true, repeat: 1 }, at);
  tl.set(rip, { x: x + 6, y: y + 6 }, at);
  tl.fromTo(rip, { opacity: 1, scale: 0.3 }, { opacity: 0, scale: 1.4, duration: 0.5, ease: 'power2.out', immediateRender: false }, at);
}
function leave(to, at) { tl.to(cur, { x: to[0], y: to[1], opacity: 0, duration: 0.55, ease: 'power2.in' }, at); }

/* ---- F1 Brand DNA ---- */
const F1 = add(pr, `<div class="abs" style="left:70px;top:0;width:780px;height:1080px"></div>`);
const f1a = add(F1, `<div class="card abs" style="left:0;top:220px;width:780px;height:94px;border-radius:47px">
  <div class="abs" style="left:28px;top:34px;color:#6b7263">${ic.globe(26)}</div>
  <div id="url" class="abs" style="left:72px;top:0;line-height:94px;font-size:28px"></div>
  <div id="bbtn" class="abs pill" style="right:18px;top:18px;height:58px;padding:0 26px;background:#15190f;color:#fff;font-size:19px">${ic.spark(18, '#D2E861')} Build Brand DNA</div></div>`);
riseIn(f1a, 17.85, { y: 40, dur: 0.9 });
typer(f1a.querySelector('#url'), 'lumora.co', 18.25, 18, true, 'Paste your website');
click(640, 268, 19.0, [900, 700]);
tl.to(f1a.querySelector('#bbtn'), { scale: 0.93, duration: 0.1, yoyo: true, repeat: 1 }, 19.0);
leave([1000, 820], 19.3);
const f1b = add(F1, `<div class="card abs" style="left:0;top:338px;width:780px;height:512px;padding:26px 28px">
  <div style="display:flex;align-items:center;gap:12px"><span style="width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:rgba(210,232,97,.45);color:#2f6b08">${ic.spark(20)}</span>
   <span style="font-size:23px;font-weight:650">What Mellox learned</span>
   <span id="st1" class="chip" style="margin-left:auto;background:#FFF3DC;color:#8a5a00">Reading your site</span>
   <span id="st2" class="chip abs" style="right:28px;top:30px;background:rgba(210,232,97,.55);color:#2f6b08;opacity:0">${ic.check(15)} Brand DNA ready</span></div>
  <div style="margin-top:18px;height:4px;border-radius:4px;background:#eef0e8;overflow:hidden"><div id="pbar1" style="height:100%;width:0;background:linear-gradient(90deg,#D2E861,#6ea62a)"></div></div>
  <div id="tiles" style="margin-top:20px;display:grid;grid-template-columns:1fr 1fr;gap:14px"></div></div>`);
riseIn(f1b, 19.15, { y: 50, dur: 0.9 });
tl.fromTo(f1b.querySelector('#pbar1'), { width: '0%' }, { width: '100%', duration: 1.2, ease: 'power1.inOut' }, 19.35);
tl.to(f1b.querySelector('#st1'), { opacity: 0, duration: 0.2 }, 20.5);
popIn(f1b.querySelector('#st2'), 20.5, { from: 0.7 });
const tiles = f1b.querySelector('#tiles');
const T = [
  `<div class="tile" style="grid-column:span 2"><div class="tlabel">Positioning</div><div class="tval" style="font-size:21px">Clean skincare for sensitive skin, backed by dermatologists.</div></div>`,
  `<div class="tile"><div class="tlabel">Who you serve</div><div class="tval">Women 25 to 40 with reactive, sensitive skin</div></div>`,
  `<div class="tile"><div class="tlabel">How you sound</div><div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">${['Calm', 'Expert', 'Reassuring'].map((c) => `<span class="chip" style="background:#fff;box-shadow:0 0 0 1px rgba(0,0,0,.07);color:#15190f;font-weight:550">${c}</span>`).join('')}</div></div>`,
  `<div class="tile"><div class="tlabel">Palette</div><div style="display:flex;gap:10px;margin-top:12px">${['#E9DCCF', '#C98E6B', '#3E4A3D', '#F6F1EA', '#8FA58A'].map((c) => `<span style="width:44px;height:44px;border-radius:12px;background:${c};box-shadow:0 0 0 1px rgba(0,0,0,.08) inset"></span>`).join('')}</div></div>`,
  `<div class="tile"><div class="tlabel">Keywords</div><div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">${['barrier repair', 'fragrance-free', 'ceramides'].map((c) => `<span class="chip" style="background:#fff;box-shadow:0 0 0 1px rgba(0,0,0,.07);color:#15190f;font-weight:550;font-size:14px">${c}</span>`).join('')}</div></div>`,
].map((h) => add(tiles, h));
riseIn(tiles.children, 19.75, { stagger: 0.13, y: 22, blur: 8, dur: 0.7 });
tl.to(F1.children, { opacity: 0, y: -40, filter: 'blur(10px)', duration: 0.45, ease: 'power2.in', stagger: 0.05 }, 21.3);

/* ---- F2 AI Visibility ---- */
const F2 = add(pr, `<div class="abs" style="left:70px;top:0;width:780px;height:1080px"></div>`);
const f2 = add(F2, `<div class="card abs" style="left:0;top:180px;width:780px;height:560px;padding:28px 30px">
  <div style="display:flex;align-items:center;gap:12px"><span style="width:40px;height:40px;border-radius:12px;display:grid;place-items:center;background:#15190f;color:#D2E861">${ic.spark(22)}</span>
    <div><div style="font-size:23px;font-weight:650;display:flex;align-items:center;gap:8px">AI Search Visibility <span style="width:9px;height:9px;border-radius:50%;background:#3aa655"></span></div>
    <div style="font-size:15px;color:#6b7263;margin-top:2px">How AI engines see <b style="color:#15190f;font-weight:600">lumora.co</b> · scanned just now</div></div>
    <span id="gain" class="chip" style="margin-left:auto;background:rgba(210,232,97,.55);color:#2f6b08;opacity:0">${ic.trend(14)} +15</span></div>
  <div style="margin-top:22px;display:flex;align-items:center;gap:26px;background:#f7f8f4;border-radius:18px;padding:18px 22px">
    <div style="position:relative;width:132px;height:132px;flex:none">
      <svg width="132" height="132" viewBox="0 0 132 132" style="transform:rotate(-90deg)"><circle cx="66" cy="66" r="54" fill="none" stroke="#e6e9df" stroke-width="11"/>
      <circle id="ring" cx="66" cy="66" r="54" fill="none" stroke="#D08A12" stroke-width="11" stroke-linecap="round" stroke-dasharray="339.3" stroke-dashoffset="339.3"/></svg>
      <div class="abs" style="inset:0;display:grid;place-items:center;text-align:center"><div><span id="score" style="font-size:44px;font-weight:650;letter-spacing:-.03em">0</span><span style="font-size:15px;color:#8a9182">/100</span></div></div></div>
    <div><div style="font-size:13px;font-weight:700;letter-spacing:.12em;color:#8a9182">GEO SCORE · 6 SIGNALS</div>
      <div id="verdict" style="margin-top:8px;font-size:25px;line-height:1.3;width:520px"></div></div></div>
  <div id="eng" style="margin-top:20px;display:flex;gap:10px"></div>
  <div id="sig" style="margin-top:20px;display:grid;grid-template-columns:repeat(6,1fr);gap:12px"></div></div>`);
riseIn(f2, 21.85, { y: 50, dur: 0.9 });
const ringEl = f2.querySelector('#ring'), scoreEl = f2.querySelector('#score'), verdict = f2.querySelector('#verdict');
const scoreAt = (t) => { if (t < 24.35) return lerp(0, 69, EMPH(seg(t, 22.1, 23.3))); return lerp(69, 84, EMPH(seg(t, 24.35, 25.15))); };
D.push((t) => {
  const s = scoreAt(t);
  ringEl.setAttribute('stroke-dashoffset', (339.3 * (1 - s / 100)).toFixed(2));
  ringEl.setAttribute('stroke', s >= 80 ? '#2E8B3D' : '#D08A12');
  scoreEl.textContent = Math.round(s);
  verdict.innerHTML = t < 24.75 ? `<b style="color:#B8740A;font-weight:650">Workable</b> <span style="color:#6b7263">· A few fixes will lift your visibility.</span>`
    : `<b style="color:#2E8B3D;font-weight:650">Strong</b> <span style="color:#6b7263">· AI engines can confidently read and cite you.</span>`;
});
tl.fromTo(verdict, { opacity: 0 }, { opacity: 1, duration: 0.4 }, 22.6);
tl.fromTo(verdict, { opacity: 0.2 }, { opacity: 1, duration: 0.35 }, 24.75);
const ENG = [['openai', 'ChatGPT', 'Mentioned'], ['gemini', 'Gemini', 'Cited'], ['claude', 'Claude', 'Missing'], ['perplexity', 'Perplexity', 'Mentioned'], ['google', 'AI Overviews', 'Cited']];
const stc = { Cited: ['#E3F4E6', '#23703A'], Mentioned: ['#FFF3DC', '#8a5a00'], Missing: ['#FDECEC', '#B4121F'] };
const engEls = ENG.map(([k, n, s]) => add(f2.querySelector('#eng'), `<div style="flex:1;background:#fff;border-radius:14px;box-shadow:0 0 0 1px rgba(0,0,0,.07);padding:12px 12px 12px;display:flex;flex-direction:column;gap:9px">
  <div style="display:flex;align-items:center;gap:8px">${logo(k, 20)}<span style="font-size:15px;font-weight:600;white-space:nowrap">${n}</span></div>
  <span class="chip" style="align-self:flex-start;padding:4px 10px;font-size:13px;background:${stc[s][0]};color:${stc[s][1]}">${s}</span></div>`));
riseIn(engEls, 22.4, { stagger: 0.08, y: 16, blur: 6, dur: 0.6 });
const SIG = [['AI bots', 50], ['Schema', 30], ['Crawl', 76], ['Content', 93], ['Trust', 75], ['Perf', 90]];
const tone = (v) => (v >= 80 ? '#2E8B3D' : v >= 55 ? '#D08A12' : '#C8102E');
SIG.forEach(([n, v], i) => {
  const e = add(f2.querySelector('#sig'), `<div><div style="font-size:12px;font-weight:700;letter-spacing:.1em;color:#8a9182;text-transform:uppercase">${n}</div>
    <div class="val" style="font-size:24px;font-weight:650;margin-top:4px">0</div><div style="margin-top:8px;height:5px;border-radius:5px;background:#eceee7;overflow:hidden"><div class="bar" style="height:100%;width:0;border-radius:5px"></div></div></div>`);
  const val = e.querySelector('.val'), bar = e.querySelector('.bar');
  D.push((t) => {
    let x = lerp(0, v, EMPH(seg(t, 22.45 + i * 0.07, 23.4 + i * 0.07)));
    if (n === 'Schema') x = t < 24.3 ? x : lerp(30, 88, EMPH(seg(t, 24.3, 25.0)));
    val.textContent = Math.round(x); val.style.color = tone(x); bar.style.width = `${x}%`; bar.style.background = tone(x);
  });
});
const fix = add(F2, `<div class="card abs" style="left:110px;top:708px;width:670px;height:96px;border-radius:24px;display:flex;align-items:center;gap:16px;padding:0 20px">
  <span style="width:48px;height:48px;border-radius:14px;display:grid;place-items:center;background:rgba(210,232,97,.45);color:#2f6b08">${ic.spark(22)}</span>
  <div><div style="font-size:20px;font-weight:650">Add FAQ schema</div><div id="fixsub" style="font-size:15px;color:#6b7263;margin-top:3px">Fix ready · 3 pages</div></div>
  <div id="fixbtn" class="pill" style="margin-left:auto;height:52px;padding:0 26px;background:#15190f;color:#fff;font-size:18px;position:relative"><span id="fx1">Fix</span></div></div>`);
riseIn(fix, 23.2, { y: 30, scale: 0.95, dur: 0.75 });
const fixbtn = fix.querySelector('#fixbtn'), fx1 = fix.querySelector('#fx1'), fixsub = fix.querySelector('#fixsub');
click(700, 756, 24.0, [980, 980]);
tl.to(fixbtn, { scale: 0.92, duration: 0.1, yoyo: true, repeat: 1 }, 24.0);
D.push((t) => {
  if (t < 24.05) { fx1.innerHTML = 'Fix'; fixbtn.style.background = '#15190f'; fixbtn.style.color = '#fff'; fixsub.textContent = 'Fix ready · 3 pages'; }
  else { fx1.innerHTML = `<span style="display:inline-flex;align-items:center;gap:6px">${ic.check(16)} Fixed</span>`; fixbtn.style.background = '#D2E861'; fixbtn.style.color = '#15190f'; fixsub.textContent = t < 24.55 ? 'Verifying with a re-scan…' : 'Verified by re-scan'; }
});
leave([1000, 1000], 24.3);
popIn(f2.querySelector('#gain'), 24.85, { from: 0.4 });
tl.to(F2.children, { opacity: 0, y: -40, filter: 'blur(10px)', duration: 0.45, ease: 'power2.in', stagger: 0.05 }, 25.3);

/* ---- F3 Create ---- */
const F3 = add(pr, `<div class="abs" style="left:70px;top:0;width:780px;height:1080px"></div>`);
const comp = add(F3, `<div class="card abs" style="left:0;top:170px;width:780px;height:88px;border-radius:44px">
  <div class="abs" style="left:18px;top:16px;width:56px;height:56px;border-radius:50%;display:grid;place-items:center;background:rgba(210,232,97,.45);color:#2f6b08">${ic.spark(24)}</div>
  <div id="ctext" class="abs" style="left:90px;top:0;line-height:88px;font-size:24px"></div>
  <div id="csend" class="abs" style="right:14px;top:14px;width:60px;height:60px;border-radius:50%;display:grid;place-items:center;color:#fff;background:#c9cdc2">${ic.up(24)}</div></div>`);
riseIn(comp, 25.85, { y: 40, dur: 0.9 });
const CP = 'A LinkedIn post for our Barrier Serum launch';
typer(comp.querySelector('#ctext'), CP, 26.1, 46, true, 'What should we make today?');
const csend = comp.querySelector('#csend');
D.push((t) => { csend.style.background = t > 26.1 + CP.length / 46 ? '#15190f' : '#c9cdc2'; });
tl.to(csend, { scale: 0.84, duration: 0.12, yoyo: true, repeat: 1 }, 27.15);
const thinkR = add(F3, `<div class="abs" style="left:10px;top:300px;display:flex;align-items:center;gap:14px">
  <span id="pulse" style="width:40px;height:40px;border-radius:50%;display:grid;place-items:center;color:#2f6b08;background:conic-gradient(from 0deg,rgba(210,232,97,0),rgba(210,232,97,.9),rgba(210,232,97,0));">${ic.spark(22)}</span>
  <span id="tlab" class="shimmer" style="font-size:22px;font-weight:600">Reading your brand</span></div>`);
tl.fromTo(thinkR, { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.3 }, 27.25);
tl.to(thinkR, { opacity: 0, duration: 0.2 }, 27.8);
D.push((t) => { thinkR.querySelector('#pulse').style.transform = `rotate(${t * 300}deg)`; thinkR.querySelector('#tlab').style.backgroundPosition = `${(1 - ((t * 0.9) % 1)) * 150}% 0`; });
const post = add(F3, `<div class="card abs" style="left:0;top:286px;width:780px;height:600px;padding:24px 26px">
  <div style="display:flex;align-items:center;gap:12px"><span style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#E9DCCF,#8FA58A)"></span>
   <div><div style="font-size:19px;font-weight:650">Lumora</div><div style="font-size:14px;color:#8a9182;display:flex;align-items:center;gap:6px">${logo('linkedin', 14)} LinkedIn · Draft</div></div>
   <span id="onb" class="chip" style="margin-left:auto;background:rgba(210,232,97,.55);color:#2f6b08">${ic.check(15)} On brand</span></div>
  <div id="art" style="position:relative;margin-top:18px;height:280px;border-radius:18px;overflow:hidden;background:linear-gradient(140deg,#F6F1EA 0%,#E9DCCF 50%,#DDE6D2 100%)">
    <div class="abs" style="left:-60px;top:40px;width:260px;height:260px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#fbf7f1,#dccbb8)"></div>
    <div class="abs" style="left:520px;top:-50px;width:240px;height:240px;border-radius:50%;background:radial-gradient(circle at 40% 40%,#eef3e6,#b9cba8)"></div>
    <div class="abs" style="left:318px;top:56px;width:112px;height:34px;border-radius:10px 10px 4px 4px;background:#3E4A3D"></div>
    <div class="abs" style="left:300px;top:86px;width:148px;height:180px;border-radius:26px;background:linear-gradient(160deg,#ffffff,#efe6db);box-shadow:0 20px 40px -18px rgba(62,74,61,.45)">
      <div class="abs" style="left:0;right:0;top:66px;text-align:center;font-family:Mich;font-size:13px;color:#3E4A3D;letter-spacing:.08em">LUMORA</div>
      <div class="abs" style="left:0;right:0;top:92px;text-align:center;font-size:12px;color:#8a7f72">Barrier Serum</div></div>
    <div id="shine" class="abs" style="top:0;bottom:0;width:240px;background:linear-gradient(100deg,transparent,rgba(255,255,255,.6),transparent)"></div></div>
  <div id="pcap" style="margin-top:18px;width:600px;font-size:19px;line-height:1.5;color:#15190f">${words('Sensitive skin deserves science, not guesswork. Meet Barrier Serum: ceramides, zero fragrance, dermatologist tested.')}</div>
  <div style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(0,0,0,.06);display:flex;align-items:center;gap:8px" id="chans">
   ${['linkedin', 'instagram', 'x', 'tiktok'].map((k) => `<span class="ch" style="width:36px;height:36px;border-radius:50%;background:#fff;display:grid;place-items:center;box-shadow:0 0 0 1px rgba(0,0,0,.07),0 2px 6px -2px rgba(16,24,8,.15)">${logo(k, 17)}</span>`).join('')}
   <span id="rdy" style="margin-left:auto;font-size:15px;color:#6b7263">Ready for 4 channels</span></div></div>`);
riseIn(post, 27.75, { y: 60, dur: 0.95 });
tl.fromTo(post.querySelector('#shine'), { x: -300 }, { x: 900, duration: 1.3, ease: 'power2.inOut' }, 28.1);
wIn(post.querySelectorAll('#pcap .w'), 28.05, { stagger: 0.035, y: 6, blur: 5, dur: 0.45 });
popIn(post.querySelectorAll('.ch'), 28.85, { stagger: 0.08, from: 0.3 });
riseIn(post.querySelector('#rdy'), 29.1, { y: 0, blur: 4, dur: 0.4 });
popIn(post.querySelector('#onb'), 28.95, { from: 0.4 });
const imgT = add(F3, `<div class="card abs" style="left:700px;top:600px;width:190px;height:210px;padding:10px;border-radius:20px">
  <div style="height:140px;border-radius:12px;background:linear-gradient(160deg,#DDE6D2,#8FA58A);position:relative;overflow:hidden"><div class="abs" style="left:60px;top:30px;width:70px;height:100px;border-radius:14px;background:#fbf7f1"></div></div>
  <div style="margin-top:12px;display:flex;align-items:center;gap:8px;font-size:15px;font-weight:600">Image <span style="margin-left:auto;font-size:13px;color:#8a9182">1:1</span></div></div>`);
const vidT = add(F3, `<div class="card abs" style="left:680px;top:330px;width:230px;height:176px;padding:10px;border-radius:20px">
  <div style="height:110px;border-radius:12px;background:linear-gradient(160deg,#3E4A3D,#1d231c);display:grid;place-items:center;color:#fff"><span style="width:48px;height:48px;border-radius:50%;background:rgba(255,255,255,.2);display:grid;place-items:center">${ic.play(22)}</span></div>
  <div style="margin-top:12px;display:flex;align-items:center;gap:8px;font-size:15px;font-weight:600">Video <span style="margin-left:auto;font-size:13px;color:#8a9182">0:15</span></div></div>`);
riseIn([imgT, vidT], 28.45, { stagger: 0.18, y: 40, scale: 0.9, dur: 0.8 });
D.push((t) => { imgT.style.translate = `0 ${Math.sin(t * 1.3) * 8}px`; vidT.style.translate = `0 ${Math.cos(t * 1.2) * 8}px`; });
tl.to(F3.children, { opacity: 0, y: -40, filter: 'blur(10px)', duration: 0.45, ease: 'power2.in', stagger: 0.04 }, 29.3);

/* ---- F4 Publish ---- */
const F4 = add(pr, `<div class="abs" style="left:70px;top:0;width:780px;height:1080px"></div>`);
const calC = add(F4, `<div class="card abs" style="left:0;top:210px;width:780px;height:540px;padding:26px 26px">
  <div style="display:flex;align-items:center;gap:10px;font-size:22px;font-weight:650">${ic.cal(22)} This week
   <div id="apv" class="pill" style="margin-left:auto;height:50px;padding:0 24px;font-size:17px;background:#15190f;color:#fff"><span id="apvt">Approve all</span></div></div>
  <div id="cols" style="margin-top:20px;display:grid;grid-template-columns:repeat(7,1fr);gap:10px"></div></div>`);
riseIn(calC, 29.85, { y: 50, dur: 0.9 });
const DAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
const cols = calC.querySelector('#cols');
const slots = DAYS.map((d, i) => {
  const c = add(cols, `<div style="display:flex;flex-direction:column;align-items:center;gap:8px"><span style="font-size:14px;font-weight:600;color:#6b7263">${d}</span>
   <span style="width:34px;height:34px;border-radius:50%;display:grid;place-items:center;font-size:15px;font-weight:650;${i === 2 ? 'background:#15190f;color:#fff' : ''}">${12 + i}</span>
   <div class="colbox" style="width:100%;height:352px;border-radius:14px;background:#f6f7f2;padding:6px;display:grid;grid-template-rows:repeat(3,1fr);gap:6px">
   ${[0, 1, 2].map(() => `<div class="slot" style="border-radius:10px;border:1.5px dashed rgba(0,0,0,.07);position:relative"></div>`).join('')}</div></div>`);
  return c.querySelectorAll('.slot');
});
const POSTS = [[0, 0, 'instagram', '#fde7f0'], [1, 1, 'linkedin', '#e3effb'], [2, 0, 'x', '#eceeea'], [2, 2, 'tiktok', '#e6f7f5'], [3, 1, 'youtube', '#fde8e6'], [4, 0, 'facebook', '#e4edfd'], [5, 2, 'threads', '#eeeeee'], [6, 1, 'linkedin', '#e3effb']];
const postEls = POSTS.map(([d, s, k, tint]) => add(slots[d][s], `<div class="abs" style="inset:-1.5px;border-radius:10px;background:${tint};display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;box-shadow:0 0 0 1px rgba(0,0,0,.05),0 6px 12px -6px rgba(16,24,8,.25)">
  ${logo(k, 24)}<span style="width:58%;height:5px;border-radius:5px;background:rgba(0,0,0,.12)"></span>
  <span class="ok" style="position:absolute;top:-7px;right:-7px;width:22px;height:22px;border-radius:50%;background:#2f6b08;color:#fff;display:grid;place-items:center;opacity:0">${ic.check(12)}</span></div>`));
tl.fromTo(postEls, { opacity: 0, y: -50, scale: 0.7 }, { opacity: 1, y: 0, scale: 1, duration: 0.6, ease: 'back.out(1.7)', stagger: 0.19 }, 30.15);
click(690, 246, 31.95, [980, 900]);
tl.to(calC.querySelector('#apv'), { scale: 0.92, duration: 0.1, yoyo: true, repeat: 1 }, 31.95);
D.push((t) => { const b = calC.querySelector('#apv'), tx = calC.querySelector('#apvt'); if (t < 32.0) { b.style.background = '#15190f'; b.style.color = '#fff'; tx.innerHTML = 'Approve all'; } else { b.style.background = '#D2E861'; b.style.color = '#15190f'; tx.innerHTML = `<span style="display:inline-flex;gap:6px;align-items:center">${ic.check(15)} Approved</span>`; } });
popIn(F4.querySelectorAll('.ok'), 32.1, { stagger: 0.05, from: 0 });
leave([1000, 1000], 32.3);
const sched = add(F4, `<div class="abs" style="left:150px;top:780px;display:flex;align-items:center;gap:14px;white-space:nowrap;border-radius:999px;background:#15190f;padding:12px 28px 12px 12px;color:#fff;font-size:20px;font-weight:600;box-shadow:0 18px 36px -12px rgba(16,24,8,.5)">
  <span style="width:38px;height:38px;border-radius:50%;background:#D2E861;color:#15190f;display:grid;place-items:center">${ic.check(18)}</span>8 posts scheduled across 7 platforms</div>`);
riseIn(sched, 32.3, { y: 24, scale: 0.9, dur: 0.7 });
tl.to(F4.children, { opacity: 0, y: -30, filter: 'blur(10px)', duration: 0.4, ease: 'power2.in', stagger: 0.04 }, 33.35);
tl.to(S6, { opacity: 0, duration: 0.3 }, 33.65);

/* =========================================================
   S7 - Real product coverflow (33.7 - 37.9)
   ========================================================= */
const S7 = layer('S7', '', 10); show(S7, 33.65, 37.95);
add(S7, `<div class="abs" style="inset:0;background:radial-gradient(1400px 700px at 50% 115%,rgba(203,233,96,.24),rgba(203,233,96,0) 60%),radial-gradient(900px 500px at 50% -10%,rgba(255,255,255,.06),transparent 60%),#050606"></div>`);
tl.fromTo(S7, { opacity: 0 }, { opacity: 1, duration: 0.35 }, 33.65);
const h7 = add(S7, `<div class="abs center-x" style="top:78px;z-index:20">
  <div style="font-family:M5;font-size:40px;color:#CBE960;letter-spacing:.06em">${words('THE REAL PRODUCT')}</div>
  <div class="head" style="margin-top:14px;font-size:54px;color:#fff">${words('Every cycle, your Brand DNA and visibility get sharper.')}</div></div>`);
wIn(h7.querySelectorAll('.w'), 33.85, { stagger: 0.045 });
const flow = add(S7, `<div class="abs" style="left:0;top:0;width:1920px;height:1080px;perspective:2400px"></div>`);
const SHOTS = [['real-chat.jpg', 1100, 619], ['real-branddna.jpg', 1000, 622], ['real-visibility.jpg', 1000, 622], ['real-design.jpg', 830, 622]];
const shotEls = SHOTS.map(([src, w, h]) => add(flow, `<div class="realshot" style="left:${960 - w / 2}px;top:${650 - h / 2}px;width:${w}px;height:${h}px"><img src="assets/${src}"></div>`));
const pAt = (t) => {
  let p = lerp(-0.9, 0, EMPH(seg(t, 33.7, 34.6)));
  [[35.05, 35.7], [35.95, 36.6], [36.85, 37.5]].forEach(([a, b]) => { p += eio(seg(t, a, b)); });
  return p;
};
D.push((t) => {
  const p = pAt(t);
  shotEls.forEach((e, i) => {
    const d = i - p, ad = Math.abs(d);
    const x = d * 700, z = -ad * 420, ry = -clamp(d, -1.3, 1.3) * 34;
    e.style.transform = `translate3d(${x}px,0,${z}px) rotateY(${ry}deg)`;
    e.style.opacity = clamp(1.15 - ad * 0.55, 0, 1).toFixed(3);
    e.style.zIndex = String(100 - Math.round(ad * 10));
  });
});
tl.to([flow, h7], { opacity: 0, scale: 1.06, duration: 0.45, ease: 'power2.in' }, 37.45);

/* =========================================================
   S8 - Agency Command Center (37.8 - 41.9)
   ========================================================= */
const S8 = layer('S8', '', 11); show(S8, 37.75, 42.0);
add(S8, `<div class="abs" style="inset:0;background:#000"></div>`);
tl.fromTo(S8, { opacity: 0 }, { opacity: 1, duration: 0.3 }, 37.75);
const NAMES = ['Northpeak', 'Cedar & Co', 'Brightline Dental', 'Lumora', 'Halden Law', 'Mirae Studio', 'Oakfield Realty', 'Tidewater Cafe', 'Vantage Fitness', 'Solis Energy', 'Kinfolk Bakery', 'Arden Clinic', 'Juniper Hotels', 'Pike Motors', 'Nova Tutors', 'Hearth Home', 'Atlas Freight', 'Blume Florals', 'Crest Dental', 'Ember Coffee', 'Fable Books', 'Grove Organics', 'Harbor Yoga', 'Iris Optics', 'Jade Spa', 'Kite Travel', 'Linden Legal', 'Meridian Wealth', 'Noble Pets', 'Orchid Beauty', 'Pioneer Build', 'Quill Media', 'Ridge Outdoors', 'Sable Fashion', 'Terra Garden'];
const AV = ['#B489D1', '#FE7032', '#2F7BFF', '#8FA58A', '#E0B04A', '#4FB3A9', '#D97757', '#7C8CF8', '#CBE960'];
const grid = add(S8, `<div class="abs" style="left:25px;top:196px;width:1870px;height:830px;transform-origin:935px 75px"></div>`);
const gcards = NAMES.map((n, i) => {
  const r = Math.floor(i / 7), c = i % 7, hl = n === 'Lumora';
  const h = 55 + ((i * 37) % 42), rev = (i * 7) % 6, sch = 6 + ((i * 11) % 19);
  const col = h > 80 ? '#D2E861' : h > 65 ? '#9fd36b' : '#E0B04A';
  const card = add(grid, `<div class="dcard abs" style="left:${c * 270}px;top:${r * 170}px;width:250px;height:150px;padding:16px;${hl ? 'box-shadow:0 0 0 2px #D2E861 inset,0 0 60px -10px rgba(210,232,97,.5)' : ''}">
    <div style="display:flex;align-items:center;gap:12px"><span style="width:40px;height:40px;border-radius:11px;background:${AV[i % AV.length]};display:grid;place-items:center;color:#0b0b0b;font-weight:750;font-size:18px">${n[0]}</span>
     <div style="min-width:0"><div style="font-size:17px;font-weight:600;color:#f3f3f3;white-space:nowrap">${n}</div><div style="font-size:13px;color:#7d807e">Workspace</div></div>
     <span class="ld" style="margin-left:auto;width:8px;height:8px;border-radius:50%;background:${rev ? '#E0B04A' : '#D2E861'}"></span></div>
    <div style="margin-top:18px;display:flex;justify-content:space-between;font-size:13px;color:#8d908e"><span>Health</span><span class="hv" style="color:#dcdcdc">${h}</span></div>
    <div style="margin-top:6px;height:5px;border-radius:5px;background:#262a28;overflow:hidden"><div class="hb" style="height:100%;width:${h}%;background:${col};border-radius:5px"></div></div>
    <div style="margin-top:12px;font-size:13px;color:#8d908e">${rev ? `${rev} to review · ` : ''}<span class="sc">${sch}</span> scheduled</div></div>`);
  const sc = card.querySelector('.sc'), ld = card.querySelector('.ld');
  D.push((t) => { sc.textContent = sch + Math.floor(clamp((t - 38.5 - (i % 5) * 0.4) / 1.3, 0, 3)); ld.style.opacity = 0.5 + 0.5 * Math.sin(t * 4 + i); });
  return card;
});
tl.fromTo(grid, { scale: 3.1, y: 269 }, { scale: 1, y: 0, duration: 2.2, ease: 'power3.inOut' }, 37.8);
const hdr = add(S8, `<div class="abs" style="left:25px;top:70px;width:1870px;height:90px;display:flex;align-items:center;gap:22px">
  <span style="display:flex;align-items:center;gap:14px;font-size:32px;font-weight:650;color:#fff">${markSvg(46)} Command Center</span>
  <div style="display:flex;gap:6px;margin-left:24px">${['Overview', 'Clients', 'Review', 'Schedule', 'Performance'].map((x, i) => `<span style="padding:10px 18px;border-radius:999px;font-size:17px;font-weight:600;${i === 1 ? 'background:#D2E861;color:#111' : 'color:#9a9d9b;box-shadow:0 0 0 1px #262a28 inset'}">${x}</span>`).join('')}</div>
  <span style="margin-left:auto;font-size:18px;color:#9a9d9b">35 clients · everything in one place</span></div>`);
riseIn(hdr, 39.35, { y: -20, blur: 8, dur: 0.7 });
const scrim = add(S8, `<div class="abs" style="inset:0;background:radial-gradient(1300px 620px at 50% 55%,rgba(0,0,0,.94),rgba(0,0,0,.74) 70%,rgba(0,0,0,.55));opacity:0"></div>`);
tl.to(scrim, { opacity: 1, duration: 0.6, ease: 'power2.out' }, 39.85);
const cap8 = add(S8, `<div class="abs center-x" style="top:380px">
  <div class="eylabel" style="color:#CBE960;font-size:20px">${words('FOR AGENCIES')}</div>
  <div class="head" style="margin-top:22px;font-size:124px;color:#fff">${words('Run one brand.')}</div>
  <div class="head" style="font-size:124px;color:#CBE960">${words('Or forty.')}</div></div>`);
const c8 = cap8.querySelectorAll('.w');
wIn([c8[0], c8[1]], 39.95, { stagger: 0.06 });
wIn([c8[2], c8[3], c8[4]], 40.1, { stagger: 0.09 });
wIn([c8[5], c8[6]], 40.7, { stagger: 0.12, dur: 1.0 });
tl.to(S8, { opacity: 0, duration: 0.4, ease: 'power2.in' }, 41.3);

/* =========================================================
   S9 - End card (41.8 - 47.2)
   ========================================================= */
const S9 = layer('S9', '', 12); show(S9, 41.7, DURATION + 1);
add(S9, `<div class="abs" style="inset:0;background:radial-gradient(1000px 700px at 90% 0%,rgba(203,233,96,.20),rgba(203,233,96,0) 60%),#39444A"></div>`);
tl.fromTo(S9, { opacity: 0 }, { opacity: 1, duration: 0.3 }, 41.65);
const t9 = add(S9, `<img class="abs" src="assets/t1.jpg" style="left:-80px;top:-100px;width:2500px;height:1320px;-webkit-mask-image:linear-gradient(105deg,transparent 30%,#000 62%),linear-gradient(to bottom,transparent 0%,#000 22%);-webkit-mask-composite:source-in;mask-composite:intersect">`);
tl.fromTo(t9, { x: 520, opacity: 0 }, { x: 0, opacity: 1, duration: 1.6, ease: 'emph' }, 41.75);
tl.to(t9, { x: -140, duration: 0.85, ease: 'none' }, 43.35);
tl.to(t9, { opacity: 0.5, x: -300, y: 470, duration: 1.3, ease: 'power2.inOut' }, 44.15);
tl.to(t9, { x: -380, duration: 1.8, ease: 'none' }, 45.45);
const pixO = `<svg width="78" height="78" viewBox="0 0 640 640" style="display:inline-block;vertical-align:-6px;margin:0 6px 0 4px"><path d="${SYM.brand.d}" fill="#E8ECE3"/></svg>`;
const L1 = add(S9, `<div class="abs" style="left:150px;top:318px;height:132px;overflow:hidden"><div style="font-family:Mich;font-size:96px;line-height:132px;color:#fff;white-space:nowrap">D${pixO}n't just rank.</div></div>`);
const L2 = add(S9, `<div class="abs" style="left:150px;top:450px;height:132px;overflow:hidden"><div style="font-family:Mich;font-size:96px;line-height:132px;color:#CBE960;white-space:nowrap">Be recommended.</div></div>`);
tl.fromTo(L1.firstElementChild, { yPercent: 110 }, { yPercent: 0, duration: 1.0, ease: 'emph' }, 41.95);
tl.fromTo(L2.firstElementChild, { yPercent: 110 }, { yPercent: 0, duration: 1.0, ease: 'emph' }, 42.2);
const sub9 = add(S9, `<div class="abs" style="left:156px;top:622px;font-size:31px;color:rgba(255,255,255,.8)">${words('One intelligent workspace. Your entire marketing stack, replaced.')}</div>`);
wIn(sub9.querySelectorAll('.w'), 42.85, { stagger: 0.04, y: 16, blur: 8 });
tl.to([L1, L2, sub9], { opacity: 0, y: -40, filter: 'blur(12px)', duration: 0.5, ease: 'power2.in', stagger: 0.05 }, 44.2);

const lock = add(S9, `<div class="abs center-x" style="top:372px;display:flex;justify-content:center;align-items:center;gap:36px">
  <div id="lmark" style="width:190px;height:103px">${markSvg(190)}</div>
  <div id="lword" style="font-family:Mich;font-size:92px;color:#fff;letter-spacing:.03em">Mellox Ai</div></div>`);
const tag = add(S9, `<div class="abs center-x" style="top:548px;font-size:34px;color:rgba(255,255,255,.82)">${words('The Marketing Intelligence Layer')}</div>`);
const url = add(S9, `<div class="abs center-x" style="top:636px"><span id="urlpill" class="pill" style="padding:14px 34px;font-size:26px;color:#CBE960;box-shadow:0 0 0 1.5px rgba(203,233,96,.8) inset;letter-spacing:.02em">mellox.ai</span></div>`);
tl.fromTo(lock.querySelector('#lmark'), { opacity: 0, scale: 0.5, rotate: -12 }, { opacity: 1, scale: 1, rotate: 0, duration: 1.0, ease: 'emph' }, 44.7);
tl.fromTo(lock.querySelector('#lword'), { opacity: 0, letterSpacing: '0.45em', filter: 'blur(12px)' }, { opacity: 1, letterSpacing: '0.03em', filter: 'blur(0px)', duration: 1.1, ease: 'emph' }, 44.85);
wIn(tag.querySelectorAll('.w'), 45.35, { stagger: 0.06 });
riseIn(url.firstElementChild, 45.75, { y: 16, blur: 6, dur: 0.7 });
tl.fromTo(lock, { scale: 1 }, { scale: 1.03, duration: 2.5, ease: 'none' }, 44.7);

/* ---------- API ---------- */
tl.to({}, { duration: 0 }, DURATION);
window.DURATION = DURATION;
window.seek = (t) => { tl.totalTime(t, false); D.forEach((f) => f(t)); };
window.ready = Promise.all([
  document.fonts.load('500 40px GSF'), document.fonts.load('40px Mich'), document.fonts.load('40px M5'), document.fonts.ready,
  ...[...document.images].map((im) => (im.complete ? Promise.resolve() : new Promise((r) => { im.onload = im.onerror = r; }))),
]).then(() => Promise.all([...document.images].map((im) => im.decode().catch(() => {})))).then(() => { window.seek(0); return true; });
