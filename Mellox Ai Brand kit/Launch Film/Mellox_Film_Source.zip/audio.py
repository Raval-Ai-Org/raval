"""Score + sound design for the Mellox AI film, synthesized from scratch (no samples)."""
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 48000
DUR = 47.2
N = int(SR * DUR)
L = np.zeros(N); R = np.zeros(N)
rng = np.random.default_rng(7)
BEAT = 60 / 100  # 100 bpm


def idx(t):
    return int(t * SR)


def place(sig, t, gain=1.0, pan=0.0):
    i = idx(t)
    if i >= N:
        return
    n = min(len(sig), N - i)
    if sig.ndim == 1:
        l = sig[:n] * gain * np.cos((pan + 1) * np.pi / 4)
        r = sig[:n] * gain * np.sin((pan + 1) * np.pi / 4)
    else:
        l, r = sig[:n, 0] * gain, sig[:n, 1] * gain
    L[i:i + n] += l; R[i:i + n] += r


def env_ar(n, a, r_shape=None):
    e = np.ones(n)
    na = max(1, int(a * SR))
    e[:na] = np.linspace(0, 1, na)
    return e


def lp(x, f, order=2):
    b, a = signal.butter(order, f / (SR / 2), 'low'); return signal.lfilter(b, a, x)


def hp(x, f, order=2):
    b, a = signal.butter(order, f / (SR / 2), 'high'); return signal.lfilter(b, a, x)


def bp(x, f1, f2, order=2):
    b, a = signal.butter(order, [f1 / (SR / 2), f2 / (SR / 2)], 'band'); return signal.lfilter(b, a, x)


# ---------------- instruments ----------------
def pad(freqs, dur, bright=1800, att=1.2, rel=1.6):
    n = int(dur * SR); t = np.arange(n) / SR
    out = np.zeros((n, 2))
    for k, f in enumerate(freqs):
        for det, side in ((-0.18, 0), (0.18, 1), (0.0, None)):
            ff = f * 2 ** (det / 12)
            ph = rng.uniform(0, 2 * np.pi)
            w = np.sin(2 * np.pi * ff * t + ph) + 0.35 * np.sin(4 * np.pi * ff * t + ph) + 0.15 * np.sin(6 * np.pi * ff * t + ph)
            if side is None:
                out[:, 0] += w * 0.6; out[:, 1] += w * 0.6
            else:
                out[:, side] += w
    e = np.minimum(1, t / att) * np.minimum(1, (dur - t) / rel)
    e = np.clip(e, 0, 1) ** 1.5
    for c in range(2):
        out[:, c] = lp(out[:, c], bright) * e
    return out / (len(freqs) * 3)


def pluck(f, dur=1.2, bright=1.0):
    n = int(dur * SR); t = np.arange(n) / SR
    w = np.sin(2 * np.pi * f * t) + 0.3 * bright * np.sin(4 * np.pi * f * t) * np.exp(-t * 9) + 0.12 * np.sin(6 * np.pi * f * t) * np.exp(-t * 14)
    return w * np.exp(-t * 4.2) * np.minimum(1, t / 0.003)


def kick(gain=1.0):
    n = int(0.5 * SR); t = np.arange(n) / SR
    f = 44 + 90 * np.exp(-t * 28)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * np.exp(-t * 7.5) * gain


def clap():
    n = int(0.25 * SR); t = np.arange(n) / SR
    x = bp(rng.standard_normal(n), 900, 3200) * np.exp(-t * 22)
    return x * 0.6


def hat(open_=False):
    n = int((0.18 if open_ else 0.05) * SR); t = np.arange(n) / SR
    return hp(rng.standard_normal(n), 7000) * np.exp(-t * (18 if open_ else 70)) * 0.35


def sub_boom(dur=2.6, f0=48):
    n = int(dur * SR); t = np.arange(n) / SR
    f = f0 + 30 * np.exp(-t * 6)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 1.6) * np.minimum(1, t / 0.005)


def whoosh(dur=0.9, f1=300, f2=4000, peak=0.6, pan_from=-0.6, pan_to=0.6, reverse=False):
    n = int(dur * SR); t = np.linspace(0, 1, n)
    x = rng.standard_normal(n)
    # sweep via crossfaded bands
    lo = bp(x, f1, f1 * 3); hi = bp(x, f2 / 3, min(f2, 20000))
    mix = lo * (1 - t) + hi * t
    e = np.where(t < peak, (t / peak) ** 2.2, ((1 - t) / (1 - peak)) ** 1.6)
    s = mix * e
    if reverse:
        s = s[::-1]
    pan = np.linspace(pan_from, pan_to, n)
    return np.stack([s * np.cos((pan + 1) * np.pi / 4), s * np.sin((pan + 1) * np.pi / 4)], 1)


def riser(dur=1.8):
    n = int(dur * SR); t = np.linspace(0, 1, n)
    x = hp(rng.standard_normal(n), 1500) * t ** 3
    tone = np.sin(2 * np.pi * np.cumsum(300 + 900 * t ** 2) / SR) * 0.15 * t ** 2
    s = x * 0.5 + tone
    return np.stack([s, s], 1)


def tick():
    n = int(0.012 * SR); t = np.arange(n) / SR
    return hp(rng.standard_normal(n), 2500) * np.exp(-t * 500) * 0.5


def click_ui():
    n = int(0.06 * SR); t = np.arange(n) / SR
    return (hp(rng.standard_normal(n), 3000) * np.exp(-t * 400) * 0.6 + np.sin(2 * np.pi * 1900 * t) * np.exp(-t * 90) * 0.35)


def chime(notes=(1318.5, 1760.0, 2637.0), spacing=0.06):
    n = int(1.4 * SR); out = np.zeros(n)
    for k, f in enumerate(notes):
        t = np.arange(n) / SR
        s = np.sin(2 * np.pi * f * t) * np.exp(-t * 5) * np.minimum(1, t / 0.002)
        sh = int(k * spacing * SR)
        out[sh:] += s[:n - sh] * (0.5 - k * 0.1)
    return out


def err_blip():
    n = int(0.36 * SR); t = np.arange(n) / SR
    f = np.where(t < 0.12, 622, 466)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-((t % 0.12) * 16)) * 0.5
    return lp(s, 3000)


def pop():
    n = int(0.09 * SR); t = np.arange(n) / SR
    f = 500 + 900 * np.exp(-t * 60)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 45) * 0.45


def impact():
    s = sub_boom(1.6, 52) * 0.9
    n = len(s); t = np.arange(n) / SR
    s += lp(rng.standard_normal(n), 2500) * np.exp(-t * 14) * 0.35
    return s


# ---------------- reverb ----------------
def reverb(x, secs=2.8, mix=0.28):
    n = int(secs * SR); t = np.arange(n) / SR
    irl = rng.standard_normal(n) * np.exp(-t * 3.2 / secs * 3)
    irr = rng.standard_normal(n) * np.exp(-t * 3.2 / secs * 3)
    irl = lp(irl, 5000); irr = lp(irr, 5000)
    irl /= np.sqrt((irl ** 2).sum()); irr /= np.sqrt((irr ** 2).sum())
    wl = signal.fftconvolve(x[:, 0], irl)[:len(x)]
    wr = signal.fftconvolve(x[:, 1], irr)[:len(x)]
    return x * (1 - mix) + np.stack([wl, wr], 1) * mix * 2.2


# ---------------- music ----------------
M = np.zeros((N, 2))


def mplace(sig, t, gain=1.0, pan=0.0):
    i = idx(t)
    if i >= N: return
    if sig.ndim == 1:
        sig = np.stack([sig * np.cos((pan + 1) * np.pi / 4), sig * np.sin((pan + 1) * np.pi / 4)], 1)
    n = min(len(sig), N - i)
    M[i:i + n] += sig[:n] * gain


D3, A3, Cs4, E4, Fs4 = 146.83, 220.0, 277.18, 329.63, 369.99
G2, B3, Fs3 = 98.0, 246.94, 185.0
B2, D4, A2, E3 = 123.47, 293.66, 110.0, 164.81

# Act 1 (light, 0 - 10): airy, D major 9 -> G maj7#11
mplace(pad([D3, A3, Cs4, E4, Fs4], 5.4, 2200, 1.5, 1.8), 0.0, 0.55)
mplace(pad([G2, D3, Fs3, B3, Cs4], 5.2, 2000, 1.2, 1.2), 4.8, 0.55)
arp1 = [Fs4 * 2, A3 * 2, E4 * 2, Cs4 * 2]
arp2 = [Fs3 * 4, D3 * 4, B3 * 2, Cs4 * 2]
t = 0.3
k = 0
while t < 9.9:
    notes = arp1 if t < 5.0 else arp2
    g = 0.11 + 0.05 * min(1, t / 6)
    mplace(pluck(notes[k % 4], 1.0), t, g, pan=(-0.35 if k % 2 else 0.35))
    t += BEAT / 2; k += 1

# Act 2 (dark reveal, 10 - 17.7): Bm9 -> G maj9
mplace(pad([B2, Fs3, A3, Cs4, D4], 4.2, 1600, 0.4, 1.4), 10.0, 0.75)
mplace(pad([G2, D3, Fs3, A3, B3], 4.4, 1800, 0.8, 1.2), 13.6, 0.7)
# pulse during brains
t = 13.8
while t < 17.6:
    mplace(kick(0.55), t, 0.8)
    t += BEAT

# Act 3 (product, 17.7 - 33.7): driving, D - A - Bm - G
prog = [([D3, A3, D4, Fs4], [Fs4 * 2, A3 * 2, D4 * 2, E4 * 2]),
        ([A2, E3, A3, Cs4], [E4 * 2, Cs4 * 2, A3 * 2, B3 * 2]),
        ([B2, Fs3, B3, D4], [D4 * 2, Fs4 * 2, B3 * 2, Cs4 * 2]),
        ([G2, D3, B3, Fs4], [B3 * 2, D4 * 2, Fs4 * 2, A3 * 2])]
bar = 4 * BEAT
t0 = 17.72
for b in range(7):
    ch, ar = prog[b % 4]
    tb = t0 + b * bar
    if tb > 33.7: break
    mplace(pad(ch, bar + 0.6, 2400, 0.25, 0.6), tb, 0.55)
    for s in range(16):
        ts = tb + s * BEAT / 4
        if ts > 33.6: break
        if s % 2 == 0:
            mplace(pluck(ar[(s // 2) % 4], 0.6), ts, 0.07, pan=(-0.4 if s % 4 else 0.4))
        mplace(hat(s % 4 == 2), ts, 0.28 if s % 2 else 0.12, pan=0.25)
    for q in range(4):
        tq = tb + q * BEAT
        if tq > 33.6: break
        mplace(kick(), tq, 0.9)
        if q in (1, 3):
            mplace(clap(), tq, 0.4, pan=-0.1)
    # bass
    n = int(bar * SR); tt = np.arange(n) / SR
    bass = np.sin(2 * np.pi * ch[0] / 2 * tt) * 0.5 + 0.2 * np.sin(2 * np.pi * ch[0] * tt)
    bass *= (0.55 + 0.45 * np.abs(np.sin(np.pi * tt / BEAT)))
    bass *= np.minimum(1, tt / 0.02) * np.minimum(1, (bar - tt) / 0.05)
    mplace(bass, tb, 0.45)

# Act 4 (real product + agency, 33.7 - 41.6): half-time, bigger
mplace(pad([B2, Fs3, A3, D4, E4], 4.3, 1500, 0.3, 0.8), 33.65, 0.7)
mplace(pad([G2, D3, A3, B3, Fs4], 4.2, 2400, 0.3, 1.5), 37.75, 0.75)
t = 33.7
while t < 41.3:
    mplace(kick(), t, 0.85)
    if t > 37.7:
        mplace(hat(), t + BEAT / 2, 0.25, pan=0.2)
    t += BEAT
t = 34.0
k = 0
while t < 41.3:
    mplace(pluck([D4 * 2, A3 * 2, Fs4 * 2, E4 * 2][k % 4], 0.8), t, 0.07, pan=(-0.3 if k % 2 else 0.3))
    t += BEAT / 2; k += 1

# Act 5 (end, 41.6 - 47.2): breath, then resolve on D add9
mplace(pad([D3, A3, E4, Fs4], 3.3, 1400, 0.4, 0.9), 41.65, 0.55)
mplace(pad([D3, A3, D4, E4, Fs4, A3 * 2], 3.0, 2600, 0.05, 2.0), 44.7, 0.85)
for k, f in enumerate([Fs4 * 2, A3 * 4, D4 * 4, E4 * 4]):
    mplace(pluck(f, 2.0), 44.75 + k * 0.12, 0.09, pan=(-0.4 + k * 0.27))

M = reverb(M, 3.0, 0.3)

# ---------------- sound design ----------------
FX = np.zeros((N, 2))


def fx(sig, t, gain=1.0, pan=0.0):
    i = idx(t)
    if i >= N: return
    if sig.ndim == 1:
        sig = np.stack([sig * np.cos((pan + 1) * np.pi / 4), sig * np.sin((pan + 1) * np.pi / 4)], 1)
    n = min(len(sig), N - i)
    FX[i:i + n] += sig[:n] * gain


fx(whoosh(1.2, 200, 3000, 0.7, -0.3, 0.3), 2.2, 0.18)            # S1 out
for i in range(6): fx(pop(), 3.15 + i * 0.08, 0.35, pan=(-0.7 if i < 3 else 0.7))  # engine discs
typing = [(3.5, 41, 31), (18.25, 9, 18), (26.1, 44, 46)]
for st, cnt, cps in typing:
    for c in range(cnt):
        fx(tick(), st + c / cps + rng.uniform(-0.004, 0.004), 0.55 * rng.uniform(0.7, 1.0), pan=rng.uniform(-0.15, 0.15))
fx(click_ui(), 4.95, 0.7)
fx(whoosh(0.8, 300, 5000, 0.5, 0.0, 0.0), 4.85, 0.16)
for i in range(3): fx(pop(), 6.25 + i * 0.12, 0.22)
fx(err_blip(), 6.95, 0.55)
fx(whoosh(0.7, 200, 2500, 0.6, 0.2, -0.2), 6.9, 0.14)
for i in range(12): fx(pop(), 7.25 + i * 0.06, 0.2, pan=rng.uniform(-0.8, 0.8))
for i in range(6): fx(tick(), 8.5 + i * 0.09, 0.8)
fx(whoosh(0.75, 250, 6000, 0.92, -0.2, 0.2, reverse=False), 9.25, 0.35)  # suck in
fx(impact(), 10.02, 0.9)
fx(whoosh(1.4, 150, 3000, 0.2, 0.5, -0.5), 10.0, 0.25)
fx(chime((880.0, 1318.5, 1760.0), 0.09), 11.05, 0.25)
fx(whoosh(0.9, 200, 2500, 0.6, -0.2, 0.2), 13.2, 0.15)
for i in range(4): fx(pop(), 14.15 + i * 0.14, 0.25, pan=[-0.6, 0.6, -0.6, 0.6][i])
fx(riser(1.0), 16.75, 0.35)
fx(whoosh(0.7, 400, 8000, 0.85), 17.1, 0.25)
fx(impact(), 17.72, 0.45)
fx(click_ui(), 19.0, 0.8)
fx(chime(), 20.5, 0.35)
fx(click_ui(), 24.0, 0.8)
fx(chime((1568.0, 2093.0, 2637.0)), 24.1, 0.3)
fx(chime((1318.5, 1760.0)), 24.85, 0.2)
fx(click_ui(), 27.15, 0.6)
fx(pop(), 28.95, 0.3)
for i in range(8): fx(pop(), 30.15 + i * 0.19 + 0.15, 0.28, pan=-0.5 + i * 0.14)
fx(click_ui(), 31.95, 0.8)
fx(chime((1318.5, 1760.0, 2217.5, 2637.0), 0.05), 32.1, 0.3)
fx(whoosh(0.8, 200, 4000, 0.7, -0.4, 0.4), 33.3, 0.2)
for a in (35.05, 35.95, 36.85):
    fx(whoosh(0.7, 250, 3500, 0.5, 0.6, -0.6), a, 0.13)
fx(whoosh(1.2, 300, 5000, 0.6, 0.3, -0.3), 37.4, 0.2)
fx(impact(), 39.95, 0.5)
fx(impact(), 40.7, 0.75)
fx(riser(1.3), 43.4, 0.25)
fx(whoosh(0.8, 200, 3000, 0.6), 44.15, 0.18)
fx(impact(), 44.72, 0.95)
fx(chime((1760.0, 2217.5, 2637.0, 3520.0), 0.07), 44.8, 0.28)
FX = reverb(FX, 1.6, 0.18)

mix = M * 0.9 + FX * 1.0
# gentle glue compression via soft clip
peak = np.abs(mix).max()
mix = mix / peak * 1.25
mix = np.tanh(mix) / np.tanh(1.25)
# fades
fi = int(0.05 * SR); mix[:fi] *= np.linspace(0, 1, fi)[:, None]
fo = int(1.2 * SR); mix[-fo:] *= np.linspace(1, 0, fo)[:, None] ** 1.5
mix *= 0.89
wavfile.write('/home/claude/work/score.wav', SR, (mix * 32767).astype(np.int16))
print('ok', mix.shape, np.abs(mix).max())
